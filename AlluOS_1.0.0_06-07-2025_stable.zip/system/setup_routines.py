import os
from system.config_manager import load_settings, save_settings, save_users, load_language_dict, get_text
from system.path_manager import USERS_JSON, HOME_PATH
from system.display_utils import clear_screen, apply_theme

def _get_input_with_theme(prompt_key, lang_dict, theme_settings, default_value=""):
    prompt_text = get_text(prompt_key, lang_dict)
    prompt_color = apply_theme(prompt_text, theme_settings, key="prompt")
    user_input = input(f"{prompt_color}: ")
    return user_input if user_input.strip() else default_value

def theme_setup(lang_dict):
    print(apply_theme(get_text("theme_setup_guide", lang_dict), {"text": "\033[0;37m", "reset": "\033[0m"}))
    header_color = _get_input_with_theme("header_color_code", lang_dict, {"prompt": "\033[1;36m", "reset": "\033[0m"}, "37")
    text_color = _get_input_with_theme("text_color_code", lang_dict, {"prompt": "\033[1;36m", "reset": "\033[0m"}, "37")
    error_color = _get_input_with_theme("error_color_code", lang_dict, {"prompt": "\033[1;36m", "reset": "\033[0m"}, "31")
    prompt_color = _get_input_with_theme("prompt_color_code", lang_dict, {"prompt": "\033[1;36m", "reset": "\033[0m"}, "36")
    file_color = _get_input_with_theme("file_color_code", lang_dict, {"prompt": "\033[1;36m", "reset": "\033[0m"}, "32")
    folder_color = _get_input_with_theme("folder_color_code", lang_dict, {"prompt": "\033[1;36m", "reset": "\033[0m"}, "34")
    bg_color = _get_input_with_theme("background_color_code", lang_dict, {"prompt": "\033[1;36m", "reset": "\033[0m"}, "")
    reset_color = "\033[0m"

    theme_settings = {
        "header": f"\033[1;{header_color}m",
        "text": f"\033[1;{text_color}m",
        "error": f"\033[1;{error_color}m",
        "prompt": f"\033[1;{prompt_color}m",
        "file": f"\033[1;{file_color}m",
        "folder": f"\033[1;{folder_color}m",
        "background": f"\033[0;{bg_color}m",
        "reset": reset_color
    }
    
    settings = load_settings()
    settings["theme"] = theme_settings
    save_settings(settings)
    return theme_settings

def systemname_setup(lang_dict, theme_settings):
    system_name = _get_input_with_theme("enter_system_name", lang_dict, theme_settings)
    
    settings = load_settings()
    settings["system_name"] = system_name
    save_settings(settings)
    return system_name

def user_setup(lang_dict, theme_settings):
    print(apply_theme(get_text('set_root_password', lang_dict), theme_settings, "text"))
    root_password = _get_input_with_theme('root_password', lang_dict, theme_settings)
    
    print(apply_theme(get_text('create_first_user', lang_dict), theme_settings, "text"))
    user_name = _get_input_with_theme('username', lang_dict, theme_settings)
    user_password = _get_input_with_theme('user_password', lang_dict, theme_settings)
    
    admin_input = _get_input_with_theme('is_admin', lang_dict, theme_settings, "n").strip().lower()
    is_admin = admin_input == "y"

    users_data = {
        "root": root_password,
        "users": [{
            "name": user_name,
            "password": user_password,
            "is_admin": is_admin
        }]
    }
    save_users(users_data)
    
    user_home = os.path.join(HOME_PATH, user_name)
    if not os.path.exists(user_home):
        os.makedirs(user_home)
    return user_name

def language_setup():
    lang_code = input("Language file: ") or "lang_en.json"
    
    settings = load_settings()
    settings["language"] = lang_code
    save_settings(settings)
    return lang_code

def run_initial_setup():
    if not os.path.exists(USERS_JSON) or os.path.getsize(USERS_JSON) == 0:
        clear_screen()
        lang_code = language_setup()
        lang_dict = load_language_dict(lang_code)
        
        print(apply_theme(get_text("welcome", lang_dict), {"text": "\033[1;32m", "reset": "\033[0m"}, "text"))
        print("----------------------------------------")
        print(get_text("setup_guide", lang_dict))
        print(get_text("setup_edit_later", lang_dict))
        
        theme_settings = theme_setup(lang_dict)
        systemname_setup(lang_dict, theme_settings)
        user_setup(lang_dict, theme_settings)
        
        print(apply_theme(get_text('setup_complete', lang_dict), theme_settings, 'header'))
        input(apply_theme(get_text('press_enter', lang_dict), theme_settings, 'prompt'))
        return True
    return False