import os
from system.display_utils import clear_screen, apply_theme
from system.config_manager import load_settings, load_language_dict, get_text
from system.command_dispatcher import dispatch_command
from system.path_manager import ROOT_PATH, HOME_PATH 

def start_system_session(username, is_admin):
    clear_screen()
    
    settings = load_settings()
    theme_settings = settings.get("theme", {})
    lang_code = settings.get("language", "lang_en.json")
    lang_dict = load_language_dict(lang_code)

    welcome_message = get_text('login_welcome', lang_dict).format(username=username)
    print(apply_theme(welcome_message, theme_settings, 'header'))
    print(apply_theme(get_text('system_ready', lang_dict), theme_settings, 'text'))
    print(apply_theme(get_text('logged_in_as', lang_dict).format(username=username, is_admin=is_admin), theme_settings, 'text'))

    user_home_path = os.path.join(HOME_PATH, username)
    try:
        os.makedirs(user_home_path, exist_ok=True)
        os.chdir(user_home_path)
    except Exception as e:
        print(apply_theme(get_text('user_home_dir_error', lang_dict).format(path=user_home_path, error=e), theme_settings, 'error'))
        print(apply_theme(get_text('cd_to_root_fallback', lang_dict), theme_settings, 'info'))
        os.chdir(ROOT_PATH)


    while True:
        try:
            current_display_path = os.getcwd()
            
            if current_display_path.startswith(ROOT_PATH):
                display_path = current_display_path[len(ROOT_PATH):]
                if not display_path:
                    display_path = '/'
                elif not display_path.startswith('/'):
                    display_path = '/' + display_path
            else:
                display_path = current_display_path

            system_name = settings.get('system_name', 'AlluOS')
            prompt_text = f"{username}@{system_name}:{display_path}> "
            user_input = input(apply_theme(prompt_text, theme_settings, 'prompt'))
            
            if user_input.strip() == "":
                continue

            dispatch_command(user_input, lang_dict, theme_settings, username, is_admin)

        except KeyboardInterrupt:
            print(apply_theme(get_text('ctrl_c_exit', lang_dict), theme_settings, 'text'))
            break
        except Exception as e:
            print(apply_theme(get_text('unexpected_system_error', lang_dict).format(error=e), theme_settings, 'error'))