import os
import importlib
from system.path_manager import SYSTEM_PATH, MODULE_PATH
from system.config_manager import get_text, load_users
from system.display_utils import apply_theme

SYSTEM_COMMANDS_PATH = os.path.join(SYSTEM_PATH, "commands")

def _load_command_module(command_name, base_path):
    module_path = os.path.join(base_path, f"{command_name}.py")
    if not os.path.exists(module_path):
        return None

    module_full_name = f"system.commands.{command_name}" if base_path == SYSTEM_COMMANDS_PATH else f"modules.user_commands.{command_name}"
    
    spec = importlib.util.spec_from_file_location(module_full_name, module_path)
    if spec is None:
        return None
    
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def dispatch_command(command_line, lang_dict, theme_settings, current_user, is_admin):
    parts = command_line.strip().split(maxsplit=1)
    if not parts:
        return False

    command_name = parts[0].lower()
    args_str = parts[1] if len(parts) > 1 else ""
    args = args_str.split()

    effective_is_admin = is_admin

    if command_name == "sudo":
        if is_admin:
            print(apply_theme(get_text('sudo_already_admin', lang_dict), theme_settings, 'info'))
            command_line_to_execute = args_str
            command_name = args[0].lower() if args else ""
            args = args[1:] if len(args) > 1 else []
        else:
            users = load_users()
            root_password_hash = users.get('root')

            if not root_password_hash:
                print(apply_theme(get_text('sudo_no_root_password', lang_dict), theme_settings, 'error'))
                return False

            password_input = input(apply_theme(get_text('sudo_password_prompt', lang_dict), theme_settings, 'prompt'))
            
            if password_input == root_password_hash:
                effective_is_admin = True
                print(apply_theme(get_text('sudo_auth_success', lang_dict), theme_settings, 'success'))
                command_line_to_execute = args_str
                command_name = args[0].lower() if args else ""
                args = args[1:] if len(args) > 1 else []
            else:
                print(apply_theme(get_text('sudo_incorrect_password', lang_dict), theme_settings, 'error'))
                return False
    else:
        command_line_to_execute = command_line

    if not command_name:
        return False

    cmd_module = _load_command_module(command_name, SYSTEM_COMMANDS_PATH)
        
    if cmd_module and hasattr(cmd_module, 'execute'):
        try:
            cmd_module.execute(args, lang_dict, theme_settings, current_user, effective_is_admin)
            return True
        except Exception as e:
            print(apply_theme(get_text('command_execution_error', lang_dict).format(command=command_name, error=e), theme_settings, 'error'))
            return False
    else:
        print(apply_theme(get_text('command_not_found', lang_dict).format(command=command_name), theme_settings, 'text'))
        return False