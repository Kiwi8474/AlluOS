import os

def clear_screen():
    os.system("clear" if os.name == "posix" else "cls")

def apply_theme(text, theme_settings, key="text"):
    color_code = theme_settings.get(key, "")
    reset_code = theme_settings.get("reset", "\033[0m")
    bg_color = theme_settings.get("background", "")
    if bg_color:
        return f"{bg_color}{color_code}{text}{reset_code}"
    return f"{color_code}{text}{reset_code}"