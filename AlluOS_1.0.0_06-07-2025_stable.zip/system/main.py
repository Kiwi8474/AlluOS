import os
import sys

from path_manager import setup_paths
setup_paths()

from display_utils import clear_screen
from config_manager import load_settings, load_language_dict, get_text
from setup_routines import run_initial_setup
from auth_manager import login_user
from core import start_system_session

def main():
    clear_screen()

    setup_performed = run_initial_setup()

    settings = load_settings()
    lang_code = settings.get("language", "lang_en.json")
    lang_dict = load_language_dict(lang_code)
    theme_settings = settings.get("theme", {})
    
    if setup_performed:
        settings = load_settings()
        theme_settings = settings.get("theme", {})
        clear_screen()

    logged_in_username, is_admin_user = login_user(lang_dict, theme_settings)
    
    if logged_in_username:
        start_system_session(logged_in_username, is_admin_user)
    else:
        print(get_text("login_failed_exit", lang_dict))
        sys.exit(1)

if __name__ == "__main__":
    main()