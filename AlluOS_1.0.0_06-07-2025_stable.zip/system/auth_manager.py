from system.config_manager import load_users, get_text
from system.display_utils import apply_theme

def login_user(lang_dict, theme_settings):
    users_data = load_users()
    if not users_data or not users_data.get("users"):
        print(get_text("no_users_found", lang_dict))
        return None, None
    
    users = users_data.get("users", [])
    
    while True:
        username = input(apply_theme(get_text('username', lang_dict), theme_settings, 'prompt') + ": ")
        user = next((u for u in users if u["name"] == username), None)
        if user:
            break
        print(apply_theme(get_text('user_not_found', lang_dict), theme_settings, 'text'))
    
    while True:
        password = input(apply_theme(get_text('user_password', lang_dict), theme_settings, 'prompt') + ": ")
        if password == user["password"]:
            is_admin = user.get("is_admin", False)
            return username, is_admin
        else:
            print(apply_theme(get_text('incorrect_password', lang_dict), theme_settings, 'text'))