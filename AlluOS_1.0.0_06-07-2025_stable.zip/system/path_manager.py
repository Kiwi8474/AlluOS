import os
import sys

ROOT_PATH = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

SYSTEM_PATH = os.path.join(ROOT_PATH, "system")
CONFIG_PATH = os.path.join(ROOT_PATH, "config")
MODULE_PATH = os.path.join(ROOT_PATH, "modules")
HOME_PATH = os.path.join(ROOT_PATH, "home")
TMP_PATH = os.path.join(ROOT_PATH, 'tmp')

SETTINGS_JSON = os.path.join(CONFIG_PATH, "settings.json")
USERS_JSON = os.path.join(CONFIG_PATH, "users.json")

def setup_paths():
    paths_to_add = [ROOT_PATH, SYSTEM_PATH, CONFIG_PATH, MODULE_PATH, HOME_PATH, TMP_PATH]
    for path in paths_to_add:
        if path not in sys.path:
            sys.path.append(path)

def get_paths():
    return {
        "root": ROOT_PATH,
        "system": SYSTEM_PATH,
        "config": CONFIG_PATH,
        "modules": MODULE_PATH,
        "home": HOME_PATH,
        "tmp": TMP_PATH,
        "settings_json": SETTINGS_JSON,
        "users_json": USERS_JSON,
    }

def get_absolute_path_in_root(relative_or_absolute_path):
    absolute_proposed_path = os.path.normpath(os.path.join(os.getcwd(), relative_or_absolute_path))

    if os.path.commonpath([ROOT_PATH, absolute_proposed_path]) == ROOT_PATH:
        return absolute_proposed_path
    else:
        return None

os.makedirs(CONFIG_PATH, exist_ok=True)
os.makedirs(MODULE_PATH, exist_ok=True)
os.makedirs(HOME_PATH, exist_ok=True)
os.makedirs(TMP_PATH, exist_ok=True)