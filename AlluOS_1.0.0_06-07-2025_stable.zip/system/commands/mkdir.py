import os
from system.display_utils import apply_theme
from system.config_manager import get_text
from system.path_manager import get_absolute_path_in_root

def execute(args, lang_dict, theme_settings, current_user, is_admin):
    if not args:
        print(apply_theme(get_text('mkdir_no_args', lang_dict), theme_settings, 'error'))
        return False

    success = True
    for path_arg in args:
        target_path = get_absolute_path_in_root(path_arg)

        if target_path is None:
            print(apply_theme(get_text('mkdir_outside_root_error', lang_dict).format(path=path_arg), theme_settings, 'error'))
            success = False
            continue

        if os.path.exists(target_path):
            print(apply_theme(get_text('mkdir_exists', lang_dict).format(path=path_arg), theme_settings, 'error'))
            success = False
            continue

        try:
            if not is_admin and not target_path.startswith(os.path.join(os.path.expanduser('~'))):
                pass
            
            os.makedirs(target_path)
            print(apply_theme(get_text('mkdir_success', lang_dict).format(path=path_arg), theme_settings, 'success'))
        except PermissionError:
            print(apply_theme(get_text('mkdir_permission_denied', lang_dict).format(path=path_arg), theme_settings, 'error'))
            success = False
        except Exception as e:
            print(apply_theme(get_text('mkdir_error', lang_dict).format(path=path_arg, error=e), theme_settings, 'error'))
            success = False
            
    return success