from system.display_utils import apply_theme

def execute(args, lang_dict, theme_settings, current_user, is_admin):
    output_text = ' '.join(args)
    print(apply_theme(output_text, theme_settings, 'text'))
    return True