import os
from system.display_utils import apply_theme
from system.config_manager import get_text, load_settings, load_language_dict
from system.path_manager import SYSTEM_PATH

def execute(args, lang_dict, theme_settings, current_user, is_admin):
    commands_dir = os.path.join(SYSTEM_PATH, "commands")

    settings = load_settings()
    lang_dict = load_language_dict(settings.get("language", "lang_en.json"))
    theme_settings = settings.get("theme", {})

    print(apply_theme(get_text('help_available_commands', lang_dict), theme_settings, 'header'))
    print(apply_theme("----------------------------------------", theme_settings, 'text'))

    try:
        command_files = [f for f in os.listdir(commands_dir) if f.endswith('.py') and f != '__init__.py' and os.path.isfile(os.path.join(commands_dir, f))]
        
        command_files.sort()

        for filename in command_files:
            command_name = filename[:-3] 
            print(apply_theme(f"- {command_name}", theme_settings, 'text'))

    except Exception as e:
        print(apply_theme(get_text('help_list_error', lang_dict).format(error=e), theme_settings, 'error'))
        return False

    print(apply_theme("----------------------------------------", theme_settings, 'text'))
    
    return True