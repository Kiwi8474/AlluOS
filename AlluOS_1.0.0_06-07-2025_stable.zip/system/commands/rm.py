import os
import shutil
from system.display_utils import apply_theme
from system.config_manager import get_text

from system.path_manager import get_absolute_path_in_root

def execute(args, lang_dict, theme_settings, current_user, is_admin):
    if not args:
        print(apply_theme(get_text('rm_usage', lang_dict), theme_settings, 'error'))
        return False

    recursive = False
    paths_to_delete = []

    if '-r' in args:
        recursive = True
        args.remove('-r')

    if not args:
        print(apply_theme(get_text('rm_usage', lang_dict), theme_settings, 'error'))
        return False

    for path_arg in args:
        abs_path = get_absolute_path_in_root(path_arg)
        if abs_path is None:
            print(apply_theme(get_text('rm_outside_root_error', lang_dict).format(path=path_arg), theme_settings, 'error'))
            continue
        if not os.path.exists(abs_path):
            print(apply_theme(get_text('rm_not_found', lang_dict).format(path=path_arg), theme_settings, 'error'))
            continue
        
        if os.path.isdir(abs_path) and not recursive:
            print(apply_theme(get_text('rm_directory_no_recursive', lang_dict).format(path=path_arg), theme_settings, 'error'))
            continue
            
        paths_to_delete.append((abs_path, path_arg))

    if not paths_to_delete:
        return False

    confirmation_message = get_text('rm_confirm_prompt', lang_dict).format(count=len(paths_to_delete))
    confirmation_input = input(apply_theme(confirmation_message, theme_settings, 'prompt'))
    
    if confirmation_input.lower() != 'y':
        print(apply_theme(get_text('rm_aborted', lang_dict), theme_settings, 'info'))
        return False

    success = True
    for abs_path, original_path_arg in paths_to_delete:
        try:
            if os.path.isfile(abs_path):
                os.remove(abs_path)
                print(apply_theme(get_text('rm_file_success', lang_dict).format(path=original_path_arg), theme_settings, 'success'))
            elif os.path.isdir(abs_path):
                shutil.rmtree(abs_path)
                print(apply_theme(get_text('rm_directory_success', lang_dict).format(path=original_path_arg), theme_settings, 'success'))
        except PermissionError:
            print(apply_theme(get_text('rm_permission_denied', lang_dict).format(path=original_path_arg), theme_settings, 'error'))
            success = False
        except Exception as e:
            print(apply_theme(get_text('rm_general_error', lang_dict).format(path=original_path_arg, error=e), theme_settings, 'error'))
            success = False
            
    return success
