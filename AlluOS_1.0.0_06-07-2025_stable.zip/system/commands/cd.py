import os
from system.display_utils import apply_theme
from system.config_manager import get_text
from system.path_manager import ROOT_PATH, get_absolute_path_in_root

def execute(args, lang_dict, theme_settings, current_user, is_admin):
    target_path = ""

    if not args:
        target_path = os.path.expanduser("~")
        try:
            os.chdir(ROOT_PATH)
            print(apply_theme(get_text('cd_to_root', lang_dict), theme_settings, 'info'))
        except Exception as e:
            print(apply_theme(get_text('cd_error', lang_dict).format(path=ROOT_PATH, error=e), theme_settings, 'error'))
        return True
    
    target_path = args[0]
    
    absolute_proposed_path = get_absolute_path_in_root(target_path)

    if absolute_proposed_path is None:
        print(apply_theme(get_text('cd_outside_root_error', lang_dict), theme_settings, 'error'))
        return False

    if not os.path.exists(absolute_proposed_path):
        print(apply_theme(get_text('cd_path_not_found', lang_dict).format(path=target_path), theme_settings, 'error'))
        return False
    
    if not os.path.isdir(absolute_proposed_path):
        print(apply_theme(get_text('cd_not_a_directory', lang_dict).format(path=target_path), theme_settings, 'error'))
        return False

    try:
        os.chdir(absolute_proposed_path)
        return True
    except PermissionError:
        print(apply_theme(get_text('cd_permission_denied', lang_dict).format(path=target_path), theme_settings, 'error'))
        return False
    except Exception as e:
        print(apply_theme(get_text('cd_error', lang_dict).format(path=target_path, error=e), theme_settings, 'error'))
        return False