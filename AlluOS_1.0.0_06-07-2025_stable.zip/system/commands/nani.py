import os
import shutil

from system.display_utils import apply_theme
from system.config_manager import load_language_dict, get_text, load_settings
from system.path_manager import CONFIG_PATH, get_absolute_path_in_root

class NaniEditor:
    def __init__(self, target_file, lang_dict, theme_settings, is_admin):
        self.target_file = get_absolute_path_in_root(target_file)
        if self.target_file is None:
            print(apply_theme(get_text('nani_outside_root_error', lang_dict), theme_settings, 'error'))
            self.running = False
            return
            
        self.lang_dict = lang_dict
        self.theme_settings = theme_settings
        self.is_admin = is_admin
        self.lines = []
        self.modified = False
        self.running = True
        self.current_line_offset = 0

        self._load_file()

    def _load_file(self):
        if not self.running:
            return

        if os.path.exists(self.target_file):
            if not os.path.isfile(self.target_file):
                print(apply_theme(get_text('nani_not_a_file', self.lang_dict).format(file=self.target_file), self.theme_settings, 'error'))
                self.running = False
                return
            try:
                with open(self.target_file, 'r') as file:
                    self.lines = file.read().splitlines()
                self.modified = False
                print(apply_theme(get_text('nani_editing_file_header', self.lang_dict).format(file=self.target_file), self.theme_settings, 'header'))
            except PermissionError:
                print(apply_theme(get_text('nani_permission_denied', self.lang_dict).format(file=self.target_file), self.theme_settings, 'error'))
                self.running = False
            except Exception as e:
                print(apply_theme(get_text('nani_read_error', self.lang_dict).format(file=self.target_file, error=e), self.theme_settings, 'error'))
                self.running = False
        else:
            print(apply_theme(get_text('nani_file_not_found_creating', self.lang_dict).format(file=self.target_file), self.theme_settings, 'info'))
            self.lines = []
            self.modified = False

    def _save_file(self):
        if not self.is_admin:
            print(apply_theme(get_text('nani_admin_required_save', self.lang_dict), self.theme_settings, 'error'))
            return False

        try:
            os.makedirs(os.path.dirname(self.target_file) or '.', exist_ok=True)
            with open(self.target_file, 'w') as file:
                file.write("\n".join(self.lines))
            self.modified = False
            print(apply_theme(get_text('nani_save_success', self.lang_dict).format(file=self.target_file), self.theme_settings, 'success'))
            return True
        except PermissionError:
            print(apply_theme(get_text('nani_permission_denied_save', self.lang_dict).format(file=self.target_file), self.theme_settings, 'error'))
            return False
        except Exception as e:
            print(apply_theme(get_text('nani_write_error', self.lang_dict).format(file=self.target_file, error=e), self.theme_settings, 'error'))
            return False

    def _display_content(self):
        max_lines_to_display = 20
        start_line = self.current_line_offset
        end_line = min(len(self.lines), start_line + max_lines_to_display)

        if not self.lines:
            print(apply_theme(get_text('nani_empty_file', self.lang_dict), self.theme_settings, 'text'))
        else:
            for i in range(start_line, end_line):
                line_num = i + 1
                line_content = self.lines[i]
                print(apply_theme(f"{line_num:4} {line_content}", self.theme_settings, 'text'))

        if len(self.lines) > max_lines_to_display:
            print(apply_theme(get_text('nani_scroll_info', self.lang_dict).format(offset=self.current_line_offset, total=len(self.lines)), self.theme_settings, 'info'))

        print(apply_theme("----------------------------------------", self.theme_settings, 'text'))
        status = get_text('nani_status_modified', self.lang_dict) if self.modified else get_text('nani_status_unmodified', self.lang_dict)
        print(apply_theme(f"{status} | {self.target_file}", self.theme_settings, 'info'))
        print(apply_theme("----------------------------------------", self.theme_settings, 'text'))


    def _get_input_from_temp_file(self, initial_content=""):
        temp_file_path = os.path.join(CONFIG_PATH, "nani_temp_edit.tmp")
        try:
            with open(temp_file_path, 'w') as f:
                f.write(initial_content)
            
            print(apply_theme(get_text('nani_external_edit_prompt', self.lang_dict).format(file=temp_file_path), self.theme_settings, 'prompt'))
            print(apply_theme(get_text('nani_external_edit_instructions', self.lang_dict), self.theme_settings, 'info'))
            
            input(apply_theme(get_text('nani_press_enter_to_continue', self.lang_dict), self.theme_settings, 'prompt'))

            with open(temp_file_path, 'r') as f:
                content = f.read().splitlines()
            return content
        except Exception as e:
            print(apply_theme(get_text('nani_temp_file_error', self.lang_dict).format(error=e), self.theme_settings, 'error'))
            return None
        finally:
            if os.path.exists(temp_file_path):
                os.remove(temp_file_path)

    def _edit_line(self, line_num):
        if not (1 <= line_num <= len(self.lines)):
            print(apply_theme(get_text('nani_invalid_line_number', self.lang_dict), self.theme_settings, 'error'))
            return

        print(apply_theme(get_text('nani_editing_line', self.lang_dict).format(line=line_num, content=self.lines[line_num - 1]), self.theme_settings, 'prompt'))
        new_content = input(apply_theme(" > ", self.theme_settings, 'prompt'))
        self.lines[line_num - 1] = new_content
        self.modified = True
        print(apply_theme(get_text('nani_line_updated', self.lang_dict), self.theme_settings, 'text'))

    def _insert_line(self, line_num):
        if not (0 <= line_num <= len(self.lines)):
            print(apply_theme(get_text('nani_invalid_insert_position', self.lang_dict), self.theme_settings, 'error'))
            return
        
        print(apply_theme(get_text('nani_insert_mode_prompt', self.lang_dict), self.theme_settings, 'prompt'))
        print(apply_theme(get_text('nani_insert_mode_instructions', self.lang_dict), self.theme_settings, 'info'))

        new_lines_input = []
        while True:
            line = input(apply_theme(" > ", self.theme_settings, 'prompt'))
            if line.strip().lower() == '!!end!!':
                break
            new_lines_input.append(line)
        
        for i, line_content in enumerate(new_lines_input):
            self.lines.insert(line_num + i, line_content)
        
        if new_lines_input:
            self.modified = True
            print(apply_theme(get_text('nani_lines_inserted', self.lang_dict).format(count=len(new_lines_input)), self.theme_settings, 'text'))
        else:
            print(apply_theme(get_text('nani_no_lines_inserted', self.lang_dict), self.theme_settings, 'info'))


    def _delete_line(self, line_num):
        if not (1 <= line_num <= len(self.lines)):
            print(apply_theme(get_text('nani_invalid_line_number', self.lang_dict), self.theme_settings, 'error'))
            return
        
        deleted_content = self.lines.pop(line_num - 1)
        self.modified = True
        print(apply_theme(get_text('nani_line_deleted', self.lang_dict).format(line=line_num, content=deleted_content), self.theme_settings, 'text'))

    def run(self):
        if not self.running:
            return False

        while self.running:
            self._display_content()
            command_input = input(apply_theme(":", self.theme_settings, 'prompt')).strip()

            if command_input.lower() == 'w':
                self._save_file()
            elif command_input.lower() == 'q':
                if self.modified:
                    print(apply_theme(get_text('nani_unsaved_changes_warning', self.lang_dict), self.theme_settings, 'warning'))
                else:
                    self.running = False
            elif command_input.lower() == 'q!':
                self.running = False
                print(apply_theme(get_text('nani_changes_discarded', self.lang_dict), self.theme_settings, 'info'))
            elif command_input.lower() == 'wq':
                if self._save_file():
                    self.running = False
            elif command_input.lower().startswith('e '):
                try:
                    line_num = int(command_input.split(' ', 1)[1])
                    self._edit_line(line_num)
                except ValueError:
                    print(apply_theme(get_text('nani_invalid_command_format', self.lang_dict), self.theme_settings, 'error'))
            elif command_input.lower().startswith('i '):
                try:
                    line_num = int(command_input.split(' ', 1)[1])
                    self._insert_line(line_num - 1)
                except ValueError:
                    print(apply_theme(get_text('nani_invalid_command_format', self.lang_dict), self.theme_settings, 'error'))
            elif command_input.lower().startswith('a '):
                try:
                    line_num = int(command_input.split(' ', 1)[1])
                    self._insert_line(line_num)
                except ValueError:
                    print(apply_theme(get_text('nani_invalid_command_format', self.lang_dict), self.theme_settings, 'error'))
            elif command_input.lower().startswith('d '):
                try:
                    line_num = int(command_input.split(' ', 1)[1])
                    self._delete_line(line_num)
                except ValueError:
                    print(apply_theme(get_text('nani_invalid_command_format', self.lang_dict), self.theme_settings, 'error'))
            elif command_input.lower() == 'next':
                self.current_line_offset += 20
                if self.current_line_offset >= len(self.lines):
                    self.current_line_offset = max(0, len(self.lines) - 20)
                print(apply_theme(get_text('nani_scrolling_down', self.lang_dict), self.theme_settings, 'info'))
            elif command_input.lower() == 'prev':
                self.current_line_offset -= 20
                if self.current_line_offset < 0:
                    self.current_line_offset = 0
                print(apply_theme(get_text('nani_scrolling_up', self.lang_dict), self.theme_settings, 'info'))
            else:
                print(apply_theme(get_text('nani_unknown_command', self.lang_dict).format(cmd=command_input), self.theme_settings, 'error'))

def execute(args, lang_dict, theme_settings, current_user, is_admin):
    settings = load_settings()
    lang_dict = load_language_dict(settings.get("language", "lang_en.json"))
    theme_settings = settings.get("theme", {})

    if not args:
        print(apply_theme(get_text('nani_no_file', lang_dict), theme_settings, 'error'))
        return False
    
    target_file = args[0]
    editor = NaniEditor(target_file, lang_dict, theme_settings, is_admin)
    editor.run()
    return True