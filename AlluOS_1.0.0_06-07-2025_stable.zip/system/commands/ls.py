import os
from system.display_utils import apply_theme
from system.config_manager import get_text
from system.path_manager import get_absolute_path_in_root

def execute(args, lang_dict, theme_settings, current_user, is_admin):
    target_path = "."

    if args:
        target_path = args[0]

    absolute_path = get_absolute_path_in_root(target_path)

    if absolute_path is None:
        print(apply_theme(get_text('ls_outside_root_error', lang_dict), theme_settings, 'error'))
        return False

    if not os.path.exists(absolute_path):
        print(apply_theme(get_text('ls_path_not_found_error', lang_dict).format(path=target_path), theme_settings, 'error'))
        return False

    try:
        with os.scandir(absolute_path) as entries:
            for entry in sorted(entries, key=lambda e: e.name.lower()):
                display_name = entry.name
                if entry.is_dir():
                    display_name += "/"
                    print(apply_theme(display_name, theme_settings, 'folder'))
                else:
                    print(apply_theme(display_name, theme_settings, 'file'))
        return True
    except PermissionError:
        print(apply_theme(get_text('ls_permission_denied_error', lang_dict).format(path=target_path), theme_settings, 'error'))
        return False
    except Exception as e:
        print(apply_theme(get_text('ls_listing_error_msg', lang_dict).format(path=target_path, error=e), theme_settings, 'error'))
        return False