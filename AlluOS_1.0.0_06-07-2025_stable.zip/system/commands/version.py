import os
import json

from system.display_utils import apply_theme
from system.config_manager import get_text, load_settings, load_language_dict
from system.path_manager import CONFIG_PATH

VERSIONS_JSON_PATH = os.path.join(CONFIG_PATH, "versions.json")

def load_versions_data():
    if os.path.exists(VERSIONS_JSON_PATH):
        try:
            with open(VERSIONS_JSON_PATH, 'r', encoding='utf-8') as f:
                return json.load(f)
        except (json.JSONDecodeError, FileNotFoundError) as e:
            print(f"Error loading versions.json: {e}")
            return None
    return None

def execute(args, lang_dict, theme_settings, current_user, is_admin):
    settings = load_settings()
    lang_dict = load_language_dict(settings.get("language", "lang_en.json"))
    theme_settings = settings.get("theme", {})

    versions_data = load_versions_data()

    print(apply_theme(get_text('version_header', lang_dict), theme_settings, 'header'))
    print(apply_theme("----------------------------------------", theme_settings, 'text'))

    if versions_data:
        sorted_components = sorted(versions_data.items(), key=lambda item: (
            0 if item[0] == "AlluOS" else 1 if item[0] == "AlluTerm" else 2 if item[0] == "AlluPackageManager" else 3, item[0]
        ))
        
        for component, info in sorted_components:
            version = info.get("version", get_text('version_not_available', lang_dict))
            description = info.get("description", "")
            author = info.get("author", "")
            release_date = info.get("release_date", "")
            mirror = info.get("mirror", "")
            
            print(apply_theme(f"{component}: {version}", theme_settings, 'text'))
            if description:
                print(apply_theme(f"  Description: {description}", theme_settings, 'text'))
            if author:
                print(apply_theme(f"  Author: {author}", theme_settings, 'text'))
            if release_date:
                print(apply_theme(f"  Release Date: {release_date}", theme_settings, 'text'))
            if mirror:
                print(apply_theme(f"  Mirror: {mirror}", theme_settings, 'text'))
            
            if component == "AlluOS":
                url = info.get("url", "")
                license_info = info.get("license", "")
                min_python_version = info.get("min_python_version", "")
                changelog_url = info.get("changelog_url", "")
                
                if url:
                    print(apply_theme(f"  URL: {url}", theme_settings, 'text'))
                if license_info:
                    print(apply_theme(f"  License: {license_info}", theme_settings, 'text'))
                if min_python_version:
                    print(apply_theme(f"  Min. Python: {min_python_version}", theme_settings, 'text'))
                if changelog_url:
                    print(apply_theme(f"  Changelog: {changelog_url}", theme_settings, 'text'))
            
            print(apply_theme("", theme_settings, 'text'))

    else:
        print(apply_theme(get_text('version_no_info', lang_dict), theme_settings, 'text'))
    
    print(apply_theme("----------------------------------------", theme_settings, 'text'))
    return True