from system.display_utils import clear_screen

def execute(args, lang_dict, theme_settings, current_user, is_admin):
    clear_screen()
    return True