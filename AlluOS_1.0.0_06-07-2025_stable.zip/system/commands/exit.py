import sys
from system.display_utils import apply_theme
from system.config_manager import get_text

def execute(args, lang_dict, theme_settings, current_user, is_admin):
    print(apply_theme(get_text("exit_message", lang_dict).format(username=current_user), theme_settings, "text"))
    sys.exit(0)