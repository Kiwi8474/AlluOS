import os
import requests
import zipfile
import json
import shutil
import time
import importlib.util

from system.display_utils import apply_theme
from system.config_manager import get_text, load_settings, load_language_dict
from system.path_manager import MODULE_PATH, SYSTEM_PATH, CONFIG_PATH, TMP_PATH

GITHUB_MODULE_BASE_URL = "http://apm-mirror.duckdns.org/apm_packages/" 

INSTALLED_MODULES_FILE = os.path.join(CONFIG_PATH, "installed_modules.json")

def _load_installed_modules():
    if os.path.exists(INSTALLED_MODULES_FILE):
        with open(INSTALLED_MODULES_FILE, 'r') as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                return {}
    return {}

def _save_installed_modules(modules_data):
    with open(INSTALLED_MODULES_FILE, 'w') as f:
        json.dump(modules_data, f, indent=4)

def _execute_installed_module(module_name, module_args, lang_dict, theme_settings, current_user, is_admin):
    module_file_path = os.path.join(SYSTEM_PATH, "commands", f"{module_name}.py")

    if not os.path.exists(module_file_path):
        print(apply_theme(get_text('command_not_found_error', lang_dict).format(command=module_name), theme_settings, 'error'))
        return False

    try:
        spec = importlib.util.spec_from_file_location(module_name, module_file_path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        if hasattr(module, 'execute'):
            return module.execute(module_args, lang_dict, theme_settings, current_user, is_admin)
        else:
            print(apply_theme(get_text('module_no_execute_error', lang_dict).format(module=module_name), theme_settings, 'error'))
            return False
    except Exception as e:
        print(apply_theme(get_text('module_execution_error', lang_dict).format(module=module_name, error=e), theme_settings, 'error'))
        return False


def execute(args, lang_dict, theme_settings, current_user, is_admin):
    settings = load_settings()
    lang_dict = load_language_dict(settings.get("language", "lang_en.json"))
    theme_settings = settings.get("theme", {})

    if not args:
        print(apply_theme(get_text('apm_usage_error', lang_dict), theme_settings, 'text'))
        return False

    command = args[0].lower()

    if command == 'install':
        if len(args) < 2:
            print(apply_theme(get_text('apm_install_usage', lang_dict), theme_settings, 'error'))
            return False
        if not is_admin:
            print(apply_theme(get_text('apm_admin_required_error', lang_dict), theme_settings, 'error'))
            return False
        module_identifier = args[1]
        return _install_simple_command_module(module_identifier, lang_dict, theme_settings)

    elif command == 'list':
        return _list_modules(lang_dict, theme_settings)

    elif command == 'uninstall':
        if len(args) < 2:
            print(apply_theme(get_text('apm_uninstall_usage', lang_dict), theme_settings, 'error'))
            return False
        if not is_admin:
            print(apply_theme(get_text('apm_admin_required_error', lang_dict), theme_settings, 'error'))
            return False
        module_name = args[1]
        return _uninstall_module(module_name, lang_dict, theme_settings)

    elif command == 'update':
        if len(args) > 1:
            print(apply_theme(get_text('apm_update_usage', lang_dict), theme_settings, 'error'))
            return False
        if not is_admin:
            print(apply_theme(get_text('apm_admin_required_error', lang_dict), theme_settings, 'error'))
            return False
        return _update_all_modules(lang_dict, theme_settings)

    elif len(args) >= 2 and args[1].lower() == 'version':
        package_name_for_version = args[0]
        return _get_module_version_info(package_name_for_version, lang_dict, theme_settings)
    
    else:
        installed_modules = _load_installed_modules()
        module_to_run_command_name = None
        for display_name, info in installed_modules.items():
            if info.get('command_name', '').lower() == command:
                module_to_run_command_name = command
                break

        if module_to_run_command_name:
            module_args_for_execution = args[1:] 
            print(apply_theme(get_text('apm_executing_module', lang_dict).format(module=module_to_run_command_name), theme_settings, 'text'))
            return _execute_installed_module(module_to_run_command_name, module_args_for_execution, lang_dict, theme_settings, current_user, is_admin)
        else:
            print(apply_theme(get_text('apm_unknown_command_error', lang_dict).format(command=" ".join(args)), theme_settings, 'error'))
            return False

def _download_module(module_identifier, lang_dict, theme_settings):
    zip_url = f"{GITHUB_MODULE_BASE_URL}{module_identifier}.zip"
    os.makedirs(TMP_PATH, exist_ok=True)
    temp_zip_path = os.path.join(TMP_PATH, f"{module_identifier}.zip")

    print(apply_theme(get_text('apm_downloading_msg', lang_dict).format(module=module_identifier), theme_settings, 'text'))
    try:
        response = requests.get(zip_url, stream=True)
        response.raise_for_status()

        with open(temp_zip_path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)
        print(apply_theme(get_text('apm_download_success', lang_dict), theme_settings, 'text'))
        return temp_zip_path
    except requests.exceptions.RequestException as e:
        print(apply_theme(get_text('apm_download_error', lang_dict).format(module=module_identifier, error=e), theme_settings, 'error'))
        return None
    except Exception as e:
        print(apply_theme(get_text('apm_download_general_error', lang_dict).format(module=module_identifier, error=e), theme_settings, 'error'))
        return None

def _install_simple_command_module(module_identifier, lang_dict, theme_settings):
    temp_zip_path = _download_module(module_identifier, lang_dict, theme_settings)
    if not temp_zip_path:
        return False

    try:
        with zipfile.ZipFile(temp_zip_path, 'r') as zip_ref:
            version_config_content = None
            command_file_content = None
            
            version_json_filename = f"{module_identifier}_version.json"
            command_py_filename = f"{module_identifier}.py"

            for name in zip_ref.namelist():
                if name == version_json_filename:
                    version_config_content = zip_ref.read(name)
                elif name == command_py_filename:
                    command_file_content = zip_ref.read(name)
            
            if not version_config_content:
                print(apply_theme(get_text('apm_no_version_config_error', lang_dict).format(file=version_json_filename), theme_settings, 'error'))
                return False
            
            if not command_file_content:
                print(apply_theme(get_text('apm_no_command_file_error', lang_dict).format(file=command_py_filename), theme_settings, 'error'))
                return False

            version_config = json.loads(version_config_content)
            
            module_display_name = version_config.get('name', module_identifier)
            module_version = version_config.get('version', 'unknown')
            module_description = version_config.get('description', '')
            module_author = version_config.get('author', '')
            
            command_name_for_shell = module_identifier
            command_file_in_zip = command_py_filename

            installed_modules = _load_installed_modules()
            for key, val in installed_modules.items():
                if val.get('command_name') == command_name_for_shell and module_identifier not in key:
                    print(apply_theme(get_text('apm_command_exists_error', lang_dict).format(command=command_name_for_shell), theme_settings, 'error'))
                    return False

            final_version_config_path = os.path.join(CONFIG_PATH, version_json_filename)
            with open(final_version_config_path, "wb") as target:
                target.write(version_config_content)
            print(apply_theme(get_text('apm_version_config_copied', lang_dict).format(file=version_json_filename), theme_settings, 'text'))

            final_command_file_path = os.path.join(SYSTEM_PATH, "commands", f"{command_name_for_shell}.py")
            with open(final_command_file_path, "wb") as target:
                target.write(command_file_content)
            print(apply_theme(get_text('apm_command_file_copied', lang_dict).format(file=command_py_filename, command=command_name_for_shell), theme_settings, 'text'))

            installed_modules = _load_installed_modules()
            installed_modules[module_display_name] = {
                "identifier": module_identifier,
                "version": module_version,
                "description": module_description,
                "author": module_author,
                "version_config_file": version_json_filename,
                "command_name": command_name_for_shell,
                "command_file": command_py_filename
            }
            _save_installed_modules(installed_modules)

        print(apply_theme(get_text('apm_install_success', lang_dict).format(module=module_display_name), theme_settings, 'text'))
        print(apply_theme(get_text('apm_restart_prompt', lang_dict), theme_settings, 'text'))
        return True

    except zipfile.BadZipFile:
        print(apply_theme(get_text('apm_zip_corrupt_error', lang_dict), theme_settings, 'error'))
        return False
    except json.JSONDecodeError:
        print(apply_theme(get_text('apm_invalid_json_config_error', lang_dict).format(file=version_json_filename), theme_settings, 'error'))
        return False
    except Exception as e:
        print(apply_theme(get_text('apm_install_general_error', lang_dict).format(module=module_identifier, error=e), theme_settings, 'error'))
        return False
    finally:
        if os.path.exists(temp_zip_path):
            os.remove(temp_zip_path)

def _list_modules(lang_dict, theme_settings):
    installed_modules = _load_installed_modules()

    print(apply_theme(get_text('apm_installed_modules_header', lang_dict), theme_settings, 'header'))
    print(apply_theme("----------------------------------------", theme_settings, 'text'))

    if not installed_modules:
        print(apply_theme(get_text('apm_no_modules_installed', lang_dict), theme_settings, 'text'))
    else:
        for module_display_name, info in sorted(installed_modules.items()):
            version = info.get('version', get_text('apm_version_unknown', lang_dict))
            command_name = info.get('command_name', get_text('apm_command_unknown', lang_dict))
            identifier = info.get('identifier', '')
            print(apply_theme(f"- {module_display_name} (v{version}) - Command: {command_name} (Identifier: {identifier})", theme_settings, 'text'))

    print(apply_theme("----------------------------------------", theme_settings, 'text'))
    return True

def _uninstall_module(module_name_to_uninstall, lang_dict, theme_settings):
    installed_modules = _load_installed_modules()

    found_module_key = None
    module_info = None
    for module_display_name, info in installed_modules.items():
        if module_display_name.lower() == module_name_to_uninstall.lower():
            found_module_key = module_display_name
            module_info = info
            break

    if not found_module_key:
        print(apply_theme(get_text('apm_module_not_found_error', lang_dict).format(module=module_name_to_uninstall), theme_settings, 'error'))
        return False

    print(apply_theme(get_text('apm_uninstall_confirm_prompt', lang_dict).format(module=found_module_key), theme_settings, 'prompt'))
    confirm = input(apply_theme("", theme_settings, 'prompt') + " (y/N): ").strip().lower()
    if confirm != 'y':
        print(apply_theme(get_text('apm_uninstall_aborted_msg', lang_dict), theme_settings, 'text'))
        return False

    try:
        command_name_for_shell = module_info.get("command_name")
        version_config_file = module_info.get("version_config_file")

        if command_name_for_shell:
            command_file_path = os.path.join(SYSTEM_PATH, "commands", f"{command_name_for_shell}.py")
            if os.path.exists(command_file_path):
                os.remove(command_file_path)
                print(apply_theme(get_text('apm_command_file_removed', lang_dict).format(command=command_name_for_shell), theme_settings, 'text'))
            else:
                print(apply_theme(get_text('apm_command_file_missing_warning', lang_dict).format(command=command_name_for_shell), theme_settings, 'text'))

        if version_config_file:
            config_file_path = os.path.join(CONFIG_PATH, version_config_file)
            if os.path.exists(config_file_path):
                os.remove(config_file_path)
                print(apply_theme(get_text('apm_version_config_removed', lang_dict).format(file=version_config_file), theme_settings, 'text'))
            else:
                print(apply_theme(get_text('apm_version_config_missing_warning', lang_dict).format(file=version_config_file), theme_settings, 'text'))

        del installed_modules[found_module_key]
        _save_installed_modules(installed_modules)

        print(apply_theme(get_text('apm_uninstall_success', lang_dict).format(module=found_module_key), theme_settings, 'text'))
        print(apply_theme(get_text('apm_restart_prompt', lang_dict), theme_settings, 'text'))

    except Exception as e:
        print(apply_theme(get_text('apm_uninstall_error', lang_dict).format(module=found_module_key, error=e), theme_settings, 'error'))
        return False

    return True

def _update_all_modules(lang_dict, theme_settings):
    print(apply_theme(get_text('apm_update_all_header', lang_dict), theme_settings, 'header'))
    installed_modules = _load_installed_modules()

    if not installed_modules:
        print(apply_theme(get_text('apm_no_modules_installed', lang_dict), theme_settings, 'text'))
        return True

    modules_to_update = list(installed_modules.keys())

    updated_count = 0
    failed_count = 0

    for module_display_name in modules_to_update:
        module_info = installed_modules.get(module_display_name)
        if not module_info:
            continue

        module_identifier = module_info.get("identifier")
        current_version = module_info.get("version", "N/A")

        if not module_identifier:
            print(apply_theme(get_text('apm_update_no_identifier_error', lang_dict).format(module=module_display_name), theme_settings, 'error'))
            failed_count += 1
            continue

        print(apply_theme(get_text('apm_updating_module', lang_dict).format(module=module_display_name, current_version=current_version), theme_settings, 'text'))
        time.sleep(0.5)

        temp_zip_path = None
        try:
            temp_zip_path = _download_module(module_identifier, lang_dict, theme_settings)
            if not temp_zip_path:
                failed_count += 1
                continue

            with zipfile.ZipFile(temp_zip_path, 'r') as zip_ref:
                version_json_filename = f"{module_identifier}_version.json"
                command_py_filename = f"{module_identifier}.py"

                version_config_content = None
                command_file_content = None

                for name in zip_ref.namelist():
                    if name == version_json_filename:
                        version_config_content = zip_ref.read(name)
                    elif name == command_py_filename:
                        command_file_content = zip_ref.read(name)

                if not version_config_content:
                    print(apply_theme(get_text('apm_no_version_config_error', lang_dict).format(file=version_json_filename), theme_settings, 'error'))
                    failed_count += 1
                    continue
                
                if not command_file_content:
                    print(apply_theme(get_text('apm_no_command_file_error', lang_dict).format(file=command_py_filename), theme_settings, 'error'))
                    failed_count += 1
                    continue

                new_version_config = json.loads(version_config_content)
                new_version = new_version_config.get('version', 'unknown')

                if new_version == current_version:
                    print(apply_theme(get_text('apm_already_latest_version', lang_dict).format(module=module_display_name, version=current_version), theme_settings, 'info'))
                    continue
                
                print(apply_theme(get_text('apm_new_version_found', lang_dict).format(current=current_version, new=new_version), theme_settings, 'text'))
                
                command_name_for_shell = module_info.get("command_name")
                version_config_file = module_info.get("version_config_file")

                if command_name_for_shell:
                    command_file_path = os.path.join(SYSTEM_PATH, "commands", f"{command_name_for_shell}.py")
                    if os.path.exists(command_file_path):
                        os.remove(command_file_path)
                        print(apply_theme(get_text('apm_command_file_removed_update', lang_dict).format(command=command_name_for_shell), theme_settings, 'text'))

                if version_config_file:
                    config_file_path = os.path.join(CONFIG_PATH, version_config_file)
                    if os.path.exists(config_file_path):
                        os.remove(config_file_path)
                        print(apply_theme(get_text('apm_version_config_removed_update', lang_dict).format(file=version_config_file), theme_settings, 'text'))

                final_version_config_path = os.path.join(CONFIG_PATH, version_json_filename)
                with open(final_version_config_path, "wb") as target:
                    target.write(version_config_content)
                
                final_command_file_path = os.path.join(SYSTEM_PATH, "commands", f"{command_name_for_shell}.py")
                with open(final_command_file_path, "wb") as target:
                    target.write(command_file_content)

                installed_modules[module_display_name] = {
                    "identifier": module_identifier,
                    "version": new_version,
                    "description": new_version_config.get('description', ''),
                    "author": new_version_config.get('author', ''),
                    "version_config_file": version_json_filename,
                    "command_name": command_name_for_shell,
                    "command_file": command_py_filename
                }
                _save_installed_modules(installed_modules)
                updated_count += 1

        except requests.exceptions.RequestException as e:
            print(apply_theme(get_text('apm_download_error', lang_dict).format(module=module_display_name, error=e), theme_settings, 'error'))
            failed_count += 1
        except zipfile.BadZipFile:
            print(apply_theme(get_text('apm_zip_corrupt_error', lang_dict), theme_settings, 'error'))
            failed_count += 1
        except json.JSONDecodeError:
            print(apply_theme(get_text('apm_invalid_json_config_error', lang_dict).format(file=version_json_filename), theme_settings, 'error'))
            failed_count += 1
        except Exception as e:
            print(apply_theme(get_text('apm_update_general_error', lang_dict).format(module=module_display_name, error=e), theme_settings, 'error'))
            failed_count += 1
        finally:
            if temp_zip_path and os.path.exists(temp_zip_path):
                os.remove(temp_zip_path)

    print(apply_theme(get_text('apm_update_summary_header', lang_dict), theme_settings, 'header'))
    print(apply_theme(get_text('apm_update_summary_updated', lang_dict).format(count=updated_count), theme_settings, 'text'))
    if failed_count > 0:
        print(apply_theme(get_text('apm_update_summary_failed', lang_dict).format(count=failed_count), theme_settings, 'error'))
    print(apply_theme("----------------------------------------", theme_settings, 'text'))
    print(apply_theme(get_text('apm_restart_prompt', lang_dict), theme_settings, 'text'))

    return True

def _get_module_version_info(package_name, lang_dict, theme_settings):
    installed_modules = _load_installed_modules()
    
    found_info = None
    for display_name, info in installed_modules.items():
        if display_name.lower() == package_name.lower() or info.get('identifier', '').lower() == package_name.lower():
            found_info = info
            break

    print(apply_theme(get_text('apm_version_header', lang_dict).format(package=package_name), theme_settings, 'header'))
    print(apply_theme("----------------------------------------", theme_settings, 'text'))

    if found_info:
        version = found_info.get("version", get_text('version_not_available', lang_dict))
        description = found_info.get("description", "")
        author = found_info.get("author", "")

        print(apply_theme(f"{found_info.get('name', package_name)}:", theme_settings, 'text'))
        print(apply_theme(f"  Version: {version}", theme_settings, 'text'))
        if description:
            print(apply_theme(f"  Description: {description}", theme_settings, 'text'))
        if author:
            print(apply_theme(f"  Author: {author}", theme_settings, 'text'))
        
        print(apply_theme("", theme_settings, 'text'))

    else:
        print(apply_theme(get_text('apm_module_not_found_error', lang_dict).format(module=package_name), theme_settings, 'text'))
        print(apply_theme(get_text('apm_version_info_not_found', lang_dict), theme_settings, 'text'))
    
    print(apply_theme("----------------------------------------", theme_settings, 'text'))
    return True