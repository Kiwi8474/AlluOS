import os
from system.display_utils import apply_theme
from system.config_manager import get_text
from system.path_manager import get_absolute_path_in_root
from system.command_dispatcher import dispatch_command

def execute(args, lang_dict, theme_settings, current_user, is_admin):
    if not args:
        print(apply_theme(get_text('sh_no_file_provided', lang_dict), theme_settings, 'error'))
        return False

    script_path_arg = args[0]
    script_abs_path = get_absolute_path_in_root(script_path_arg)

    if script_abs_path is None:
        print(apply_theme(get_text('sh_outside_root_error', lang_dict).format(path=script_path_arg), theme_settings, 'error'))
        return False

    if not os.path.exists(script_abs_path):
        print(apply_theme(get_text('sh_file_not_found', lang_dict).format(path=script_path_arg), theme_settings, 'error'))
        return False

    if not os.path.isfile(script_abs_path):
        print(apply_theme(get_text('sh_not_a_file', lang_dict).format(path=script_path_arg), theme_settings, 'error'))
        return False

    try:
        with open(script_abs_path, 'r') as file:
            for line_num, line in enumerate(file, 1):
                clean_line = line.strip()
                if not clean_line or clean_line.startswith('#'):
                    continue
                
                dispatch_command(clean_line, lang_dict, theme_settings, current_user, is_admin)
                
        return True
    except PermissionError:
        print(apply_theme(get_text('sh_permission_denied', lang_dict).format(file=script_path_arg), theme_settings, 'error'))
        return False
    except Exception as e:
        print(apply_theme(get_text('sh_execution_error', lang_dict).format(file=script_path_arg, error=e), theme_settings, 'error'))
        return False