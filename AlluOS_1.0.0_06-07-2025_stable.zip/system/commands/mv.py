import os
import shutil
from system.display_utils import apply_theme
from system.config_manager import get_text
from system.path_manager import get_absolute_path_in_root

def execute(args, lang_dict, theme_settings, current_user, is_admin):
    if len(args) != 2:
        print(apply_theme(get_text('mv_usage', lang_dict), theme_settings, 'error'))
        return False

    source_path_arg = args[0]
    destination_path_arg = args[1]

    source_abs_path = get_absolute_path_in_root(source_path_arg)
    destination_abs_path = get_absolute_path_in_root(destination_path_arg)

    if source_abs_path is None:
        print(apply_theme(get_text('mv_source_outside_root_error', lang_dict).format(path=source_path_arg), theme_settings, 'error'))
        return False

    if destination_abs_path is None:
        print(apply_theme(get_text('mv_destination_outside_root_error', lang_dict).format(path=destination_path_arg), theme_settings, 'error'))
        return False

    if not os.path.exists(source_abs_path):
        print(apply_theme(get_text('mv_source_not_found', lang_dict).format(path=source_path_arg), theme_settings, 'error'))
        return False

    if not is_admin:
        pass

    try:
        shutil.move(source_abs_path, destination_abs_path)
        print(apply_theme(get_text('mv_success', lang_dict).format(source=source_path_arg, destination=destination_path_arg), theme_settings, 'success'))
        return True
    except PermissionError:
        print(apply_theme(get_text('mv_permission_denied', lang_dict).format(source=source_path_arg, destination=destination_path_arg), theme_settings, 'error'))
        return False
    except shutil.Error as e:
        print(apply_theme(get_text('mv_shutil_error', lang_dict).format(source=source_path_arg, destination=destination_path_arg, error=e), theme_settings, 'error'))
        return False
    except Exception as e:
        print(apply_theme(get_text('mv_general_error', lang_dict).format(source=source_path_arg, error=e), theme_settings, 'error'))
        return False