import json
import os
from system.path_manager import SETTINGS_JSON, USERS_JSON, CONFIG_PATH

def load_json_file(file_path):
    if os.path.exists(file_path) and os.path.getsize(file_path) > 0:
        with open(file_path, "r") as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                print(f"Warnung: {file_path} ist leer oder ungültiges JSON. Erstelle neue Konfiguration.")
                return {}
            except Exception as e:
                print(f"Fehler beim Laden von {file_path}: {e}")
                return {}
    return {}

def save_json_file(file_path, data):
    with open(file_path, "w") as f:
        json.dump(data, f, indent=4)

def load_settings():
    return load_json_file(SETTINGS_JSON)

def save_settings(settings):
    save_json_file(SETTINGS_JSON, settings)

def load_users():
    return load_json_file(USERS_JSON)

def save_users(users_data):
    save_json_file(USERS_JSON, users_data)

def load_language_dict(lang_code):
    lang_file = os.path.join(CONFIG_PATH, lang_code)
    return load_json_file(lang_file)

def get_text(key, lang_dict):
    return lang_dict.get(key, key)